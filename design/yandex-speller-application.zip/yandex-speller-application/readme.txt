=== Yandex Speller Application ===
Contributors: Dmitry Ponomarev A.
Donate link: 
Tags: speller, yandex, wysiwyg, tinymce
Requires at least: 2.8.4
Tested up to: 2.9
Stable tag: trunk

Проверка правописания в TinyMCE, используя Яндекс.Спеллер.

== Description ==

Модифицирует в визуальном редакторе TinyMCE стандартную проверку правописания на проверку правописания используя сервис <a href="http://api.yandex.ru/speller/doc/dg/concepts/speller-overview.xml">Яндекс.Спеллер</a>, что очень подходит для проверки текстов на русском языке.

== Installation ==

1. Распакуйте архив yandex-speller-application.zip в /wp-content/plugins/ директорию.
2. Активируйте плагин в "Plugins" меню в WordPress.

== Screenshots ==

1. В выпадающем списке теперь есть проверка правописания на русском, английском, украинском языках, используя Яндекс.Спеллер.
2. Предложен список слов с правильным написанием.
