=== Q2W3 Yandex Speller ===
Contributors: Max Bond
Tags: post, comments, tinymce, spellchecker, yandex speller, russian spelling, ukrainian spelling
Requires at least: 2.8.0
Tested up to: 3.0.1
stable tag: trunk

This plugin enables Russian, Ukrainian and English spelling for standard TinyMCE editor.

== Description ==

This plugin enables Russian, Ukrainian and English spelling for standard TinyMCE editor.  

Плагин заменяет стандартный набор языков для спел-чекера TinyMCE. 
После установки для проверки правописания будут доступны 3 языка: русский, украинский и английский.
С версии 1.0 доступна опция проверки правописания для комментариев (в публичной части WordPress) - основное отличие от [Yandex Speller Application](http://wordpress.org/extend/plugins/yandex-speller-application/).

Плагин использует сервис проверки правописания Яндекс.Спеллер

Известные проблемы:
1. Если в проверяемом тексте содержится отформатированный текст (`<pre>`), то включение проверки правописания сбивает форматирование.

Из-за этого рекомендую производить проверку правописания после написания всего поста. 
После проверки правописания, сохранять пост только убедившись, что форматирование не нарушено.

== Installation ==

1. Разархивировать и загрузить папку `q2w3-yandex-speller` на сервер в директорию `/wp-content/plugins/`.
2. Активировать плагин в панели управления WordPress.

== Changelog ==

= 1.0.1 =
* Исправлены ошибки инициализации TinyMCE для комментариев.

= 1.0 =
* Модификация .htaccess теперь не требуется.
* Добавлена опция отключения украинского и английского языков.
* Добавлена опция включения редактора TinyMCE с проверкой правописания для комментариев (спасибо [mk](http://wordpress.org/extend/plugins/profile/mk_is_here) и его плагину [TinyMCEComments](http://wordpress.org/extend/plugins/tinymcecomments/))

= 0.9.1 =
* Исправлена ошибка при активации: `Fatal error: Cannot redeclare q2w3_yandex_speller_activate()`

= 0.9.0 =
* Первый релиз